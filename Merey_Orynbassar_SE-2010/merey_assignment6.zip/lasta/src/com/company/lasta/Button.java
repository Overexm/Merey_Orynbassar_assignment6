package com.company.lasta;

public interface Button {
    void render();
    void onClick(String a);

}
