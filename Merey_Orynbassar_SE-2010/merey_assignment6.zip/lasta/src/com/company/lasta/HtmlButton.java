package com.company.lasta;

public class HtmlButton implements Button{
    @Override
    public void render() {
        System.out.println("This is HTML Button");
    }

    @Override
    public void onClick(String a) {

    }
}
