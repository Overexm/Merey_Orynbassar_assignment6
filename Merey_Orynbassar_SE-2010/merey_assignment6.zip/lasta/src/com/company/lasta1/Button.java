package com.company.lasta1;

public interface Button {
    void paint();
}
