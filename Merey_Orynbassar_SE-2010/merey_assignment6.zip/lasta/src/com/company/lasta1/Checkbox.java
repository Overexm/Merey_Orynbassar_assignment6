package com.company.lasta1;

public interface Checkbox {
    void paint();
}
