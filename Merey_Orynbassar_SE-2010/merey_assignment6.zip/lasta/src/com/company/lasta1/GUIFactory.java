package com.company.lasta1;




public interface GUIFactory {
    Button createButton();
    Checkbox createCheckbox();
}
