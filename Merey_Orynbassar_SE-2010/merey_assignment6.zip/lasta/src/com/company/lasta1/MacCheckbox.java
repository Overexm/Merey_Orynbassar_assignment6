package com.company.lasta1;



public class MacCheckbox implements Checkbox {
    @Override
    public void paint() {
        System.out.println("This is Mac Checkbox");
    }
}
