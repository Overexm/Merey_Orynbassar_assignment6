package com.company.lasta1;



public class WinButton implements Button {
    @Override
    public void paint() {

    }
}
