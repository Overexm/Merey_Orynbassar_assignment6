package com.company.lasta1;



public class WinCheckbox implements Checkbox {
    @Override
    public void paint() {

    }
}
