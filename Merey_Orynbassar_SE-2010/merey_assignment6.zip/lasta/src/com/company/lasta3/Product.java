package com.company.lasta3;

public class Product {

}
