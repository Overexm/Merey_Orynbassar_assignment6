package com.company.lasta3;

public class SportEngine extends Engine{
    public SportEngine(String name) {
        super(name);
    }


}
